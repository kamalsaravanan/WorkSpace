package controllers;

import com.fasterxml.jackson.databind.JsonNode;
import play.mvc.Controller;
import play.mvc.Result;
import play.mvc.Http;
import java.util.*;

import static play.libs.Json.toJson;

/**
 * This controller contains an action to handle HTTP requests
 * to the application's home page.
 */
public class HomeController extends Controller {

    /**
     * An action that renders an HTML page with a welcome message.
     * The configuration in the <code>routes</code> file means that
     * this method will be called when the application receives a
     * <code>GET</code> request with a path of <code>/</code>.
     */
    public Result index() {
        return ok(views.html.index.render());
    }

    public Result explore() {
        return ok(views.html.explore.render());
    }

    public Result tutorial() {
        return ok(views.html.tutorial.render());
    }


    public Result plainText() {

        return ok("welcome to Indium Software");
    }

    List<HashMap<String, Object>> users = new ArrayList<HashMap<String, Object>>();

    HashMap<String, Object> user = new HashMap<String, Object>();

    public List<HashMap<String, Object>> listOfUsers() {

        HashMap<String, Object> user1 = new HashMap<String, Object>();
        user1.put("id", 1001);
        user1.put("name", "AAAAA");
        user1.put("email", "aaaaa@mail.com");

        users.add(user1);

        HashMap<String, Object> user2 = new HashMap<String, Object>();
        user2.put("id", 1002);
        user2.put("name", "BBB");
        user2.put("email", "bbb@mail.com");

        users.add(user2);

        HashMap<String, Object> user3 = new HashMap<String, Object>();
        user3.put("id", 1003);
        user3.put("name", "CCC");
        user3.put("email", "ccc@mail.com");

        users.add(user3);

        HashMap<String, Object> user4 = new HashMap<String, Object>();
        user4.put("id", 1004);
        user4.put("name", "DDD");
        user4.put("email", "ddd@mail.com");

        users.add(user4);

        HashMap<String, Object> user5 = new HashMap<String, Object>();
        user5.put("id", 1005);
        user5.put("name", "EEE");
        user5.put("email", "eee@mail.com");

        users.add(user1);

        return users;
    }


    public Result jsonMap() {

        HashMap<String, Object> result = new HashMap<String, Object>() {
            {
                put("Name", "Kamal");
                put("Id", 123);
            }
        };

        return ok(toJson(result));
    }


    public Result getListOfUsers() {

        //listOfUsers();
        String str = request().getQueryString("userId");
        if (str != null) {
            int id = Integer.parseInt(str);
            Iterator itr = users.iterator();

            while (itr.hasNext()) {

                HashMap<String, Object> user = (HashMap<String, Object>) itr.next();
                if (user.containsValue(id)) {

                    return ok(toJson(user));
                }
            }

        }


        return ok(toJson(this.users));
    }

    public Result addUser() {

        JsonNode input = request().body().asJson();
        if (input != null) {
            String name = input.findPath("name").textValue();
            int id = input.findPath("id").asInt();
            String email = input.findPath("email").asText();
            String pwd = input.findPath("pwd").asText();

          String password =  AesEncrypt.encrypt(pwd,"IndiumWebServices..!");

          String Decrypt=AesEncrypt.decrypt(password,"IndiumWebServices..!");
            System.out.println(Decrypt);

            HashMap<String, Object> newuser = new HashMap<String, Object>();
            newuser.put("id", +id);
            newuser.put("name", name);
            newuser.put("email", email);
            newuser.put("password",password);
            users.add(newuser);

            return ok(toJson(newuser));
        } else {
            return ok("BAD REQUEST");
        }
    }

    public Result deleteUser() {
        int id = request().body().asJson().findPath("id").asInt();

        Iterator itr = users.iterator();

        while (itr.hasNext()) {

            HashMap<String, Object> user = (HashMap<String, Object>) itr.next();
            if (user.containsValue(id)) {
                itr.remove();
            }
        }
        return ok(toJson(id));
    }

    public Result updateUser() {
        int id = request().body().asJson().findPath("id").asInt();
        String name = request().body().asJson().findPath("name").asText();
        String email = request().body().asJson().findPath("email").asText();

        Iterator itr = users.iterator();
        if (id != 0) {
            while (itr.hasNext()) {

                HashMap<String, Object> user = (HashMap<String, Object>) itr.next();
                if (user.containsValue(id)) {
                    user.replace("name", name);
                    user.replace("email", email);
                    return ok(toJson("Updated Values" + user));
                }
            }

        }

        return badRequest();
    }


    public Result putUser() {
        JsonNode input = request().body().asJson();
        if (input != null) {
            for (JsonNode userList : input.withArray("users")) {
                String name = userList.get("name").asText();
                int id = userList.get("id").asInt();
                String email = userList.get("email").asText();
                String pwd = input.findPath("pwd").asText();

                String passowrd =  AesEncrypt.encrypt("Indium@123","IndiumWebServices..!");


                HashMap<String, Object> newuser = new HashMap<String, Object>();
                newuser.put("id", +id);
                newuser.put("name", name);
                newuser.put("email", email);
                newuser.put("Client secret",passowrd);

                users.add(newuser);
            }

            return ok(toJson("Added Users" + users));
        } else {
            return ok();

        }
    }




    public Result test(){
        System.out.println("This is test app");
        return  ok();
    }



    public Result  accessToken()
    {



        return ok();
    }


}
